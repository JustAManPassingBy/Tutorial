#include "instruction.h"
#include <stdio.h>

#define DEBUG (0)

const char* get_inst_type(const int ir) {
  // Loads
  if (get_opcode(ir)==OP_LB && get_funct3(ir)==FUNCT3_LB) 
    return "LB";
  else if (get_opcode(ir)==OP_LH && get_funct3(ir)==FUNCT3_LH) 
    return "LH";
  else if (get_opcode(ir)==OP_LW && get_funct3(ir)==FUNCT3_LW) 
    return "LW";
  else if (get_opcode(ir)==OP_LBU && get_funct3(ir)==FUNCT3_LBU) 
    return "LBU";
  else if (get_opcode(ir)==OP_LHU && get_funct3(ir)==FUNCT3_LHU) 
    return "LHU";
  // Stores
  else if (get_opcode(ir)==OP_SB && get_funct3(ir)==FUNCT3_SB) 
    return "SB";
  else if (get_opcode(ir)==OP_SH && get_funct3(ir)==FUNCT3_SH) 
    return "SH";
  else if (get_opcode(ir)==OP_SW && get_funct3(ir)==FUNCT3_SW) 
    return "SW";
  // Shifts
  else if (get_opcode(ir)==OP_SLL && get_funct3(ir)==FUNCT3_SLL &&
      get_funct7(ir)==FUNCT7_SLL) 
    return "SLL";
  else if (get_opcode(ir)==OP_SLLI && get_funct3(ir)==FUNCT3_SLLI &&
      get_funct7(ir)==FUNCT7_SLLI) 
    return "SLLI";
  else if (get_opcode(ir)==OP_SRL && get_funct3(ir)==FUNCT3_SRL &&
      get_funct7(ir)==FUNCT7_SRL) 
    return "SRL";
  else if (get_opcode(ir)==OP_SRLI && get_funct3(ir)==FUNCT3_SRLI &&
      get_funct7(ir)==FUNCT7_SRLI) 
    return "SRLI";
  else if (get_opcode(ir)==OP_SRA && get_funct3(ir)==FUNCT3_SRA &&
      get_funct7(ir)==FUNCT7_SRA) 
    return "SRA";
  else if (get_opcode(ir)==OP_SRAI && get_funct3(ir)==FUNCT3_SRAI &&
      get_funct7(ir)==FUNCT7_SRAI) 
    return "SRAI";
  // Arithmetic
  else if (get_opcode(ir)==OP_ADD && get_funct3(ir)==FUNCT3_ADD &&
      get_funct7(ir)==FUNCT7_ADD) 
    return "ADD";
  else if (get_opcode(ir)==OP_ADDI && get_funct3(ir)==FUNCT3_ADDI)
    return "ADDI";
  else if (get_opcode(ir)==OP_SUB && get_funct3(ir)==FUNCT3_SUB &&
      get_funct7(ir)==FUNCT7_SUB) 
    return "SUB";
  else if (get_opcode(ir)==OP_LUI)
    return "LUI";
  else if (get_opcode(ir)==OP_AUIPC)
    return "AUIPC";
  // Logical
  else if (get_opcode(ir)==OP_XOR && get_funct3(ir)==FUNCT3_XOR &&
      get_funct7(ir)==FUNCT7_XOR) 
    return "XOR";
  else if (get_opcode(ir)==OP_XORI && get_funct3(ir)==FUNCT3_XORI)
    return "XORI";
  else if (get_opcode(ir)==OP_OR && get_funct3(ir)==FUNCT3_OR &&
      get_funct7(ir)==FUNCT7_OR) 
    return "OR";
  else if (get_opcode(ir)==OP_ORI && get_funct3(ir)==FUNCT3_ORI)
    return "ORI";
  else if (get_opcode(ir)==OP_AND && get_funct3(ir)==FUNCT3_AND &&
      get_funct7(ir)==FUNCT7_AND) 
    return "AND";
  else if (get_opcode(ir)==OP_ANDI && get_funct3(ir)==FUNCT3_ANDI)
    return "ANDI";
  // Compare
  else if (get_opcode(ir)==OP_SLT && get_funct3(ir)==FUNCT3_SLT &&
      get_funct7(ir)==FUNCT7_SLT) 
    return "SLT";
  else if (get_opcode(ir)==OP_SLTI && get_funct3(ir)==FUNCT3_SLTI)
    return "SLTI";
  else if (get_opcode(ir)==OP_SLTU && get_funct3(ir)==FUNCT3_SLTU &&
      get_funct7(ir)==FUNCT7_SLTU) 
    return "SLTU";
  else if (get_opcode(ir)==OP_SLTIU && get_funct3(ir)==FUNCT3_SLTIU)
    return "SLTIU";
  // Branches
  else if (get_opcode(ir)==OP_BEQ && get_funct3(ir)==FUNCT3_BEQ)
    return "BEQ";
  else if (get_opcode(ir)==OP_BNE && get_funct3(ir)==FUNCT3_BNE)
    return "BNE";
  else if (get_opcode(ir)==OP_BLT && get_funct3(ir)==FUNCT3_BLT)
    return "BLT";
  else if (get_opcode(ir)==OP_BGE && get_funct3(ir)==FUNCT3_BGE)
    return "BGE";
  else if (get_opcode(ir)==OP_BLTU && get_funct3(ir)==FUNCT3_BLTU)
    return "BLTU";
  else if (get_opcode(ir)==OP_BGEU && get_funct3(ir)==FUNCT3_BGEU)
    return "BGEU";
  // Jump & Link
  else if (get_opcode(ir)==OP_JAL)
    return "JAL";
  else if (get_opcode(ir)==OP_JALR)
    return "JALR";
  else
    return "NOP";
}

int get_opcode(const int ir) {
  return ((unsigned int)ir & OP_MASK) >> OP_DIST;
}

int get_rs1(const int ir) {
  return ((unsigned int)ir & RS1_MASK) >> RS1_DIST;
}

int get_rs2(const int ir) {
  return ((unsigned int)ir & RS2_MASK) >> RS2_DIST;
}

int get_rd(const int ir) {
  return ((unsigned int)ir & RD_MASK) >> RD_DIST;
}

int get_funct3(const int ir) {
  return ((unsigned int)ir & FUNCT3_MASK) >> FUNCT3_DIST;
}

int get_funct7(const int ir) {
  return ((unsigned int)ir & FUNCT7_MASK) >> FUNCT7_DIST;
}

int get_imme_i(const int ir) {
  int result = ((unsigned int)ir & IMME_MASK) >> IMME_DIST;
  if (result & 0x00000800)
    result |= 0xFFFFF000;
  return result;
}

int get_imme_s(const int ir) {
  int funct7 = get_funct7(ir);
  int rd = get_rd(ir);
  int result = (funct7 << 5) + rd;
  if (result & 0x00000800)
    result |= 0xFFFFF000;
  return result;
}

int get_imme_u(const int ir) {
  // WARNING: This function doesn't use shift!!!
  return ir & 0xFFFFF000;
}

int get_imme_sb(const int ir) {
  int funct7 = get_funct7(ir);
  int rd = get_rd(ir);
  int result = 0;

  result |= ((int)((ir & 0x80000000)) >> 19);
  result |= ((ir & 0x00000080) << 4);
  result |= ((ir & 0x7E000000) >> 20);
  result |= ((ir & 0x00000F00) >> 7);
  return result;
}

int get_imme_uj(const int ir) {
  int result = 0;
  result |= (((int)(ir & 0x80000000)) >> 12);
  result |= ((ir & 0x000FF000));
  result |= ((ir & 0x00100000) >> 9);
  result |= ((ir & 0x7E000000) >> 20);
  result |= ((ir & 0x01E00000) >> 20);
  return result;
}

int sign_extend_sb(int result)
{
	if (result & 0x1000)
	{
		result |= 0xFFFFE000;
	}
	
	return result;
}


int get_mem_word(State *state, const int addr)
{
	return  ((unsigned char)state->mem[addr + 3] << 0  ) |
    		((unsigned char)state->mem[addr + 2] << 8  ) |
    		((unsigned char)state->mem[addr + 1] << 16 ) |
    		((unsigned char)state->mem[addr + 0] << 24 );
}

char get_mem_byte(State *state, const int addr)
{
	return state->mem[addr];
}

void set_mem_word(State *state, const int addr, const int val)
{
	state->mem[addr + 3] = (char)((val & 0x000000FF) >> 0);
	state->mem[addr + 2] = (char)((val & 0x0000FF00) >> 8);
	state->mem[addr + 1] = (char)((val & 0x00FF0000) >> 16);
	state->mem[addr + 0] = (char)((val & 0xFF000000) >> 24);

#if (DEBUG == 1)
	printf("[set_mem_word] val : 0x%8x addr : 0x%8x\n", val, addr);
#endif
}

void set_mem_byte(State *state, const int addr, const int val)
{
#if (DEBUG == 1)
	printf("[set_mem_byte] : val : 0x%8x addr : 0x%8x\n", val, addr);
#endif
	int little_endian_addr = (addr / 4) * 4 + (3 - (addr % 4));

        ((unsigned char*)state->mem)[little_endian_addr] = (unsigned char)(val & 0x000000FF);
}

int execute_inst(State *state) {
  const char *inst_type;
  int rs1, rs2, rd, imme, value;
  int shift_amount;
  int effective_addr = -1;

  state->ir = 
    ((unsigned char)state->mem[state->pc+3] << 0) | 
    ((unsigned char)state->mem[state->pc+2] << 8) |
    ((unsigned char)state->mem[state->pc+1] << 16 ) |
    ((unsigned char)state->mem[state->pc+0] << 24 );

  inst_type = get_inst_type(state->ir);
  rs1 = get_rs1(state->ir);
  rs2 = get_rs2(state->ir);
  rd  = get_rd(state->ir);

#if (DEBUG == 1)
  printf("[PC 0x%3x] : ir [0x%8x] it : %s, rs1 : %d, rs2 : %d, rd : %d\n", state->pc,
	state->ir, inst_type, rs1, rs2, rd);
#endif

  // In most case, pc is not taken.
  state->pc += 4;

  // Change state
  // Loads
  if (!strcmp(inst_type,"LW")) {
	effective_addr = get_imme_i(state->ir) + state->regs[rs1];
	state->regs[rd] = get_mem_word(state, effective_addr);
  }
  //Stores
  else if (!strcmp(inst_type,"SB")) {
	// This might not be covered. need to check
	effective_addr = get_imme_s(state->ir) + state->regs[rs1];
#if (DEBUG == 1)
	printf("SB : effective addr : 0x%8x : 0x%8x[imm] + 0x%8x[rs1]\n", effective_addr, get_imme_s(state->ir), state->regs[rs1]);
#endif
	set_mem_byte(state, effective_addr, state->regs[rs2]);
  }
  else if (!strcmp(inst_type,"SW")) {
	effective_addr = get_imme_s(state->ir) + state->regs[rs1];
#if (DEBUG == 1)
	printf("SW : effective addr : 0x%8x : 0x%8x[imm] + 0x%8x[rs1]\n", effective_addr, get_imme_s(state->ir), state->regs[rs1]);
#endif
	set_mem_word(state, effective_addr, state->regs[rs2]); 
 }
  // Shifts
  else if (!strcmp(inst_type,"SLLI")) {
	// imm[11:5] should be 0
	shift_amount = get_imme_i(state->ir);
	state->regs[rd] = (state->regs[rs1] << shift_amount);
#if (DEBUG == 1)
	printf("SLLI : 0x%8x[rd] = 0x%8x[rs1] << %d\n", state->regs[rd], state->regs[rs1], shift_amount);
#endif
  }
  else if (!strcmp(inst_type,"SRLI")) {
	// imm[11:5] should be 0
	shift_amount = get_imme_i(state->ir);
	state->regs[rd] = (int)((unsigned int)state->regs[rs1] >> shift_amount);
  }
  else if (!strcmp(inst_type,"SRAI")) {
	// imm[11:5] should be 0b 0100000
	shift_amount = get_imme_i(state->ir) & 0x1F;
	state->regs[rd] = state->regs[rs1] >> shift_amount;
  }
  // Arithmetic
  else if (!strcmp(inst_type,"ADD")) {
    state->regs[rd] = state->regs[rs1] + state->regs[rs2];
  }
  else if (!strcmp(inst_type,"ADDI")) {
    state->regs[rd] = state->regs[rs1] + get_imme_i(state->ir);
#if (DEBUG == 1)
	printf("[ADDI] : %d[rd] = %d[rs1] + %d[imm]\n", state->regs[rd], state->regs[rs1], get_imme_i(state->ir));
#endif 
  }
  else if (!strcmp(inst_type,"SUB")) {
	if (rd != 0)
	{
		state->regs[rd] = state->regs[rs1] - state->regs[rs2];
	}
  }
  else if (!strcmp(inst_type,"LUI")) {
	if (rd != 0)
	{
		state->regs[rd] = get_imme_u(state->ir);
  	}
  }
  // Logical
  else if (!strcmp(inst_type,"XOR")) {
	if (rd != 0)
	{
		state->regs[rd] = state->regs[rs1] ^ state->regs[rs2];
  	}
  }
  else if (!strcmp(inst_type,"OR")) {
	if (rd != 0)
	{
		state->regs[rd] = state->regs[rs1] | state->regs[rs2];
	}
  }
  else if (!strcmp(inst_type,"AND")) {
	if (rd != 0)
	{
		state->regs[rd] = state->regs[rs1] & state->regs[rs2];
	}
  }
  // Compare
  else if (!strcmp(inst_type,"SLT")) { // Not in testcase
	if (rd != 0)
	{
		state->regs[rd] = ((state->regs[rs1] < state->regs[rs2]) ? (1) : (0));
  	}
  }
  // Branches
  else if (!strcmp(inst_type,"BEQ")) {
	imme = (state->pc - 4) + sign_extend_sb(get_imme_sb(state->ir));

	if (state->regs[rs1] == state->regs[rs2])
	{
		state->pc = imme & 0xFFFFFFFE;
	}
  }
  else if (!strcmp(inst_type,"BNE")) {
 	imme = (state->pc - 4) + sign_extend_sb(get_imme_sb(state->ir));

        if (state->regs[rs1] != state->regs[rs2])
        {
                state->pc = imme & 0xFFFFFFFE;
        }
  }
  else if (!strcmp(inst_type,"BLT")) {
        imme = (state->pc - 4) + sign_extend_sb(get_imme_sb(state->ir));

        if (state->regs[rs1] < state->regs[rs2])
        {
                state->pc = imme & 0xFFFFFFFE;
	}
  }
  else if (!strcmp(inst_type,"BGE")) {
        imme = (state->pc - 4) + sign_extend_sb(get_imme_sb(state->ir));

        if (state->regs[rs1] >= state->regs[rs2])
        {
                state->pc = imme & 0xFFFFFFFE;
        }
  }
  else if (!strcmp(inst_type,"BLTU")) {
        imme = (state->pc - 4) + sign_extend_sb(get_imme_sb(state->ir));

        if ((unsigned int)state->regs[rs1] < (unsigned int)state->regs[rs2])
	{
		state->pc = imme & 0xFFFFFFFE;
        } 
  }
  // Jump & Link
  else if (!strcmp(inst_type,"JAL")) {
	imme = (state->pc - 4) + get_imme_i(state->ir);
	
	// Register 0 is zero_only
	if (rd != 0)
	{
		state->regs[rd] = state->pc;
	}

	state->pc = imme & 0xFFFFFFFE;
  }
  else if (!strcmp(inst_type,"JALR")) {
    imme = get_imme_i(state->ir);
    if (rd != 0) {
      // Register x0 can be used as the destination if the result is not required.
      state->regs[rd] = state->pc;
    }
    state->pc = ((state->regs[rs1] + imme) & 0xFFFFFFFE);
  }
  return effective_addr;
}

void print_state(const int prev_pc, const State *state, int effective_addr) {
  printf("---------------------------------------\n");
  printf("PC: 0x%08X\n",prev_pc);
  printf("IR: 0x%08X (Instruction: %s)\n\n",state->ir, get_inst_type(state->ir));
  printf("GPR:\n");
  for (int i=0; i<REG_SIZE; i+=4) {
    for (int j=0; j<4; j++)
      printf("[%02d] 0x%08x  ",i+j,state->regs[i+j]);
    printf("\n");
  }
  if (effective_addr != -1) {
    printf("MEM:\n");
    int base = effective_addr / 16 * 16;
    for (int i=-1; i<2; i++) {
      printf("0x%03X: ",base+16*i);
      for (int j=0; j<16; j++) {
        printf("%02hhX ", state->mem[base+16*i+j]);
      }
      printf("\n");
    }
  }
  printf("---------------------------------------\n");
}



void fprint_state(FILE *file, const int prev_pc, const State *state, int effective_addr) {
  fprintf(file,"------------------------------------------------------\n");
  fprintf(file, "PC: 0x%08X\n",prev_pc);
  fprintf(file, "IR: 0x%08X (Next Instruction: %s)\n\n",state->ir, get_inst_type(state->ir));
  fprintf(file, "GPR:\n");
  for (int i=0; i<REG_SIZE; i+=4) {
    for (int j=0; j<4; j++)
      fprintf(file, "[%02d] 0x%08X  ",i+j,state->regs[i+j]);
    fprintf(file, "\n");
  }
  if (effective_addr != -1) {
    fprintf(file, "MEM:\n");
    int base = effective_addr / 16 * 16;
    for (int i=-1; i<2; i++) {
      fprintf(file, "0x%03X: ",base+16*i);
      for (int j=0; j<16; j++) {
        fprintf(file, "%02hhX ", state->mem[base+16*i+j]);
      }
      fprintf(file, "\n");
    }
  }
  fprintf(file,"------------------------------------------------------\n");
}

